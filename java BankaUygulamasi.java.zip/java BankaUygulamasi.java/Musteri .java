 public class Musteri {
    String ad;
    String islem;
    int siraNo;

    public Musteri(String ad, String islem, int siraNo) {
        this.ad = ad;
        this.islem = islem;
        this.siraNo = siraNo;
    }

    public void bilgileriGoster() {
        System.out.println("[" + siraNo + "] " + ad + " - İşlem: " + islem);
    }
}