 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class VeritabaniBaglantisi {
    public static void main(String[] args) {
        // localhost kısmına kendi SQL Server adını da yazabilirsin
        String connectionUrl = 
            "jdbc:sqlserver://localhost:1433;" +
            "databaseName=BankaSimulasyonu;" +
            "integratedSecurity=true;" +
            "encrypt=true;trustServerCertificate=true;";

        try (Connection con = DriverManager.getConnection(connectionUrl)) {
            System.out.println("Bağlantı başarıyla kuruldu!");
        } catch (SQLException e) {
            // Hata olursa burada ne olduğunu göreceğiz
            e.printStackTrace();
        }
    }
}