import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.Duration;
import java.util.LinkedList;
import java.util.Queue;
import java.util.ArrayList;

public class BankaArayuz {
    // KUYRUKLAR (Hafızada tutar)
    static Queue<String> qYatirma = new LinkedList<>(), qCekme = new LinkedList<>(), 
                        qKredi = new LinkedList<>(), qHesap = new LinkedList<>(), qFatura = new LinkedList<>();
    
    // MODELLER (Ekranda gösterir)
    static DefaultListModel<String> mYatirma = new DefaultListModel<>(), mCekme = new DefaultListModel<>(),
                                   mKredi = new DefaultListModel<>(), mHesap = new DefaultListModel<>(), mFatura = new DefaultListModel<>();

    static ArrayList<String> gunlukRaporVerileri = new ArrayList<>();
    static int yS = 100, cS = 100, kS = 100, hS = 100, fS = 100;
    static LocalDateTime tYatirma = null, tCekme = null, tKredi = null, tHesap = null, tFatura = null;
    static final int BEKLEME = 120; // 120 saniye = 2 dakika
    static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");

    public static void main(String[] args) {
        // Renklerin Windows tarafından bozulmaması için CrossPlatform temasını seçiyoruz
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); } catch (Exception e) {}
        kimlikGirisEkrani();
    }

    // 1. ADIM: GİRİŞ EKRANI
    public static void kimlikGirisEkrani() {
        JFrame loginFrame = new JFrame("KASTAMONU BANKA - GİRİŞ");
        loginFrame.setSize(500, 550);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setLayout(new GridBagLayout());
        loginFrame.getContentPane().setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblSlogan = new JLabel("🏦 KASTAMONU BANKASI", SwingConstants.CENTER);
        lblSlogan.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblSlogan.setForeground(new Color(0, 51, 102));

        JTextField txtTC = new JTextField(15);
        JTextField txtAd = new JTextField(15);
        txtTC.setFont(new Font("Consolas", Font.BOLD, 22));

        JButton btnGiris = createKioskBtn("SİSTEME GİRİŞ YAP ➜", new Color(0, 51, 102));

        gbc.gridx = 0; gbc.gridy = 0; loginFrame.add(lblSlogan, gbc);
        gbc.gridy = 1; loginFrame.add(new JLabel("TC Kimlik No (11 Hane):"), gbc);
        gbc.gridy = 2; loginFrame.add(txtTC, gbc);
        gbc.gridy = 3; loginFrame.add(new JLabel("Ad Soyad:"), gbc);
        gbc.gridy = 4; loginFrame.add(txtAd, gbc);
        gbc.gridy = 5; loginFrame.add(btnGiris, gbc);

        btnGiris.addActionListener(e -> {
            if (txtTC.getText().length() == 11 && !txtAd.getText().isEmpty()) {
                loginFrame.dispose();
                islemSecimEkrani(txtTC.getText(), txtAd.getText());
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Lütfen bilgileri doğru giriniz!");
            }
        });

        loginFrame.setLocationRelativeTo(null);
        loginFrame.setVisible(true);
    }

    // 2. ADIM: İŞLEM SEÇİMİ (KIOSK)
    public static void islemSecimEkrani(String tc, String ad) {
        JFrame kioskFrame = new JFrame("İŞLEM SEÇİM PANELİ");
        kioskFrame.setSize(900, 600);
        kioskFrame.setLayout(new BorderLayout(10, 10));

        JLabel header = new JLabel("Hoş Geldiniz, " + ad.toUpperCase(), SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 20));
        header.setOpaque(true);
        header.setBackground(new Color(0, 51, 102));
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(900, 60));

        JPanel pnl = new JPanel(new GridLayout(2, 3, 20, 20));
        pnl.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        pnl.add(createKioskBtn("💰 PARA YATIRMA", new Color(0, 102, 51), e -> siraVer("Yatırma", tc, ad)));
        pnl.add(createKioskBtn("💸 PARA ÇEKME", new Color(0, 51, 153), e -> siraVer("Çekme", tc, ad)));
        pnl.add(createKioskBtn("💳 KREDİ KARTI", new Color(102, 0, 102), e -> siraVer("Kredi", tc, ad)));
        pnl.add(createKioskBtn("📝 HESAP AÇMA", new Color(153, 76, 0), e -> siraVer("Hesap", tc, ad)));
        pnl.add(createKioskBtn("🧾 FATURA ÖDEME", new Color(153, 0, 0), e -> siraVer("Fatura", tc, ad)));

        JButton btnYetkili = new JButton("🔐 YETKİLİ GİRİŞİ");
        btnYetkili.setBackground(Color.BLACK); btnYetkili.setForeground(Color.WHITE);
        btnYetkili.addActionListener(e -> {
            String s = JOptionPane.showInputDialog("Şifre Giriniz:");
            if ("1234".equals(s)) veznePaneliAc();
        });

        kioskFrame.add(header, BorderLayout.NORTH);
        kioskFrame.add(pnl, BorderLayout.CENTER);
        kioskFrame.add(btnYetkili, BorderLayout.SOUTH);
        kioskFrame.setLocationRelativeTo(null);
        kioskFrame.setVisible(true);
    }

    private static void siraVer(String tip, String tc, String ad) {
        String no = "";
        if (tip.equals("Yatırma")) { yS++; no = "Y-" + yS; }
        else if (tip.equals("Çekme")) { cS++; no = "C-" + cS; }
        else if (tip.equals("Kredi")) { kS++; no = "K-" + kS; }
        else if (tip.equals("Hesap")) { hS++; no = "H-" + hS; }
        else { fS++; no = "F-" + fS; }

        String detay = no + " | " + ad + " | " + LocalDateTime.now().format(dtf);
        
        if (tip.equals("Yatırma")) { qYatirma.add(detay); mYatirma.addElement(detay); }
        else if (tip.equals("Çekme")) { qCekme.add(detay); mCekme.addElement(detay); }
        else if (tip.equals("Kredi")) { qKredi.add(detay); mKredi.addElement(detay); }
        else if (tip.equals("Hesap")) { qHesap.add(detay); mHesap.addElement(detay); }
        else { qFatura.add(detay); mFatura.addElement(detay); }

        gunlukRaporVerileri.add("[" + tip.toUpperCase() + "] " + detay + " (TC: " + tc + ")");
        JOptionPane.showMessageDialog(null, "SIRA NUMARANIZ: " + no);
    }

    // 3. ADIM: PERSONEL PANELİ
    public static void veznePaneliAc() {
        JFrame vFrame = new JFrame("VEZNE ÇAĞRI SİSTEMİ");
        vFrame.setSize(1200, 600);
        vFrame.setLayout(new BorderLayout());

        JPanel pnlVezneler = new JPanel(new GridLayout(1, 5, 10, 10));
        pnlVezneler.add(vezneKutusu("VEZNE 1 (Yatır)", mYatirma, qYatirma, "Yatırma"));
        pnlVezneler.add(vezneKutusu("VEZNE 2 (Çek)", mCekme, qCekme, "Çekme"));
        pnlVezneler.add(vezneKutusu("VEZNE 3 (Kredi)", mKredi, qKredi, "Kredi"));
        pnlVezneler.add(vezneKutusu("VEZNE 4 (Hesap)", mHesap, qHesap, "Hesap"));
        pnlVezneler.add(vezneKutusu("VEZNE 5 (Fatura)", mFatura, qFatura, "Fatura"));

        JButton btnRapor = new JButton("📊 GÜNLÜK İŞLEM RAPORUNU AÇ");
        btnRapor.setBackground(new Color(0, 51, 102)); btnRapor.setForeground(Color.WHITE);
        btnRapor.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnRapor.addActionListener(e -> raporSayfasiAc());

        vFrame.add(pnlVezneler, BorderLayout.CENTER);
        vFrame.add(btnRapor, BorderLayout.SOUTH);
        vFrame.setLocationRelativeTo(null);
        vFrame.setVisible(true);
    }

    private static JPanel vezneKutusu(String baslik, DefaultListModel<String> model, Queue<String> kuyruk, String tip) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder(baslik));
        JList<String> list = new JList<>(model);
        p.add(new JScrollPane(list), BorderLayout.CENTER);

        JButton btn = new JButton("SIRADAKİ ÇAĞIR");
        btn.setBackground(new Color(0, 102, 51)); btn.setForeground(Color.WHITE);
        btn.addActionListener(e -> {
            if (siraKontrol(tip)) { // 2 Dakika Kontrolü
                if (!kuyruk.isEmpty()) {
                    kuyruk.poll(); // Kuyruktan sil
                    model.remove(0); // Ekranda listeden sil
                    JOptionPane.showMessageDialog(null, "Müşteri Çağrıldı!");
                } else {
                    JOptionPane.showMessageDialog(null, "Bekleyen kimse yok!");
                }
            }
        });
        p.add(btn, BorderLayout.SOUTH);
        return p;
    }

    // 2 DAKİKA BEKLEME KONTROLÜ
    public static boolean siraKontrol(String tip) {
        LocalDateTime simdi = LocalDateTime.now();
        LocalDateTime hedef = (tip.equals("Yatırma")) ? tYatirma : (tip.equals("Çekme")) ? tCekme : 
                             (tip.equals("Kredi")) ? tKredi : (tip.equals("Hesap")) ? tHesap : tFatura;

        if (hedef != null) {
            long fark = Duration.between(hedef, simdi).getSeconds();
            if (fark < BEKLEME) {
                JOptionPane.showMessageDialog(null, "🚫 VEZNE DOLU! Kalan: " + (BEKLEME - fark) + " sn.");
                return false;
            }
        }
        if(tip.equals("Yatırma")) tYatirma = simdi; else if(tip.equals("Çekme")) tCekme = simdi;
        else if(tip.equals("Kredi")) tKredi = simdi; else if(tip.equals("Hesap")) tHesap = simdi; else tFatura = simdi;
        return true;
    }

    // RAPOR AYRI SAYFADA AÇILIR
    private static void raporSayfasiAc() {
        JFrame rFrame = new JFrame("GÜNLÜK BANKA RAPORU");
        rFrame.setSize(600, 500);
        DefaultListModel<String> rm = new DefaultListModel<>();
        for(String s : gunlukRaporVerileri) rm.addElement(s);
        JList<String> rl = new JList<>(rm);
        rFrame.add(new JScrollPane(rl));
        rFrame.setLocationRelativeTo(null);
        rFrame.setVisible(true);
    }

    // RENKLERİN BOZULMAMASI İÇİN ÖZEL BUTON YAPICI
    private static JButton createKioskBtn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setFont(new Font("Segoe UI", Font.BOLD, 16));
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setOpaque(true);
        b.setBorderPainted(false);
        return b;
    }

    private static JButton createKioskBtn(String text, Color bg, java.awt.event.ActionListener al) {
        JButton b = createKioskBtn(text, bg);
        b.addActionListener(al);
        return b;
    }
}