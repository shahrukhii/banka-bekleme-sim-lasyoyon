 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import java.time.Duration;
import java.util.Scanner;

public class BankaUygulamasi {

    // Veritabanı bağlantı bilgileri (SQL Server kurulunca burayı kullanacağız)
    private static final String URL = "jdbc:sqlserver://localhost;databaseName=BankaSimulasyonu;integratedSecurity=true;trustServerCertificate=true;";
    
    // Sıra bekleme kuralı için değişkenler
    private static LocalDateTime sonIslemZamani = null;
    private static final int BEKLEME_SURESI_DAKIKA = 2;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("--- KASTAMONU ÜNİVERSİTESİ BANKA SİMÜLASYONUNA HOŞ GELDİNİZ ---");

        while (true) {
            System.out.println("\n1- Para Yatır");
            System.out.println("2- Para Çek");
            System.out.println("3- Çıkış");
            System.out.print("Seçiminiz: ");
            int secim = scanner.nextInt();

            if (secim == 3) break;

            // İŞLEM ÖNCESİ 2 DAKİKA KONTROLÜ
            if (siraKontrolEt()) {
                switch (secim) {
                    case 1:
                        System.out.print("Yatırılacak miktar: ");
                        double miktarYatir = scanner.nextDouble();
                        islemKaydet("Para Yatırma", miktarYatir);
                        break;
                    case 2:
                        System.out.print("Çekilecek miktar: ");
                        double miktarCek = scanner.nextDouble();
                        islemKaydet("Para Çekme", miktarCek);
                        break;
                }
            }
        }
        scanner.close();
    }

    // 2 DAKİKA KURALINI KONTROL EDEN METOD
    public static boolean siraKontrolEt() {
        LocalDateTime suAn = LocalDateTime.now();

        if (sonIslemZamani != null) {
            long gecenSaniye = Duration.between(sonIslemZamani, suAn).getSeconds();
            long beklemeSaniyesi = BEKLEME_SURESI_DAKIKA * 60;

            if (gecenSaniye < beklemeSaniyesi) {
                System.out.println("\n[!] UYARI: Vezne şu an meşgul.");
                System.out.println("[!] Lütfen " + (beklemeSaniyesi - gecenSaniye) + " saniye bekleyiniz.");
                return false;
            }
        }
        
        sonIslemZamani = suAn;
        return true;
    }

    // SQL VERİTABANINA KAYIT ATAN METOD
    public static void islemKaydet(String islemTuru, double miktar) {
        System.out.println("İşlem veritabanına işleniyor: " + islemTuru + " -> " + miktar + " TL");
        
        /* SQL BAĞLANTISI AKTİF OLDUĞUNDA BU KISIM ÇALIŞACAK
        try (Connection conn = DriverManager.getConnection(URL)) {
            String sql = "INSERT INTO IslemLoglari (IslemTuru, Miktar, Tarih) VALUES (?, ?, GETDATE())";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, islemTuru);
            pstmt.setDouble(2, miktar);
            pstmt.executeUpdate();
            System.out.println("Veritabanı başarıyla güncellendi.");
        } catch (Exception e) {
            System.out.println("Veritabanı hatası: " + e.getMessage());
        }
        */
    }
}